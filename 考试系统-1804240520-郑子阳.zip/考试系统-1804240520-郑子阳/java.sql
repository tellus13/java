/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50729
 Source Host           : localhost:3306
 Source Schema         : java

 Target Server Type    : MySQL
 Target Server Version : 50729
 File Encoding         : 65001

 Date: 26/06/2020 21:30:13
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for base
-- ----------------------------
DROP TABLE IF EXISTS `base`;
CREATE TABLE `base`  (
  `id` int(255) NOT NULL,
  `text` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `A` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `B` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `C` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `D` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `answer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of base
-- ----------------------------
INSERT INTO `base` VALUES (1, '1+1=?', 'A.1', 'B.2', 'C.3', 'D.4', 'B');
INSERT INTO `base` VALUES (2, '2+2=?', 'A.4', 'B.6', 'C.7', 'D.8', 'A');
INSERT INTO `base` VALUES (3, '3+3=?', 'A.5', 'B.6', 'C.7', 'D.8', 'B');
INSERT INTO `base` VALUES (4, '4+4=?', 'A.5', 'B.6', 'C.7', 'D.8', 'D');
INSERT INTO `base` VALUES (5, '5+5=?', 'A.10', 'B.11', 'C.12', 'D.13', 'A');
INSERT INTO `base` VALUES (6, '6+6=?', 'A.10', 'B.11', 'C.12', 'D.13', 'C');
INSERT INTO `base` VALUES (7, '7+7=?', 'A.14', 'B.15', 'C.16', 'D.17', 'A');
INSERT INTO `base` VALUES (8, '8+8=?', 'A.14', 'B.15', 'C.16', 'D.17', 'C');
INSERT INTO `base` VALUES (9, '9+9=?', 'A.18', 'B.19', 'C.20', 'D.21', 'A');
INSERT INTO `base` VALUES (10, '10+10=？', 'A.20', 'B.21', 'C.22', 'D.23', 'A');

SET FOREIGN_KEY_CHECKS = 1;
